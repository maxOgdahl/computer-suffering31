#include <iostream>
#include <string>
using namespace std;


int main()
{
	int rentalDays; 
	int odoStart;
	int odoEnd;
	int rentalMonth;
	char luxury;
	string customerName;
	// Most variables are defined here at the beginning of the code

	cout.setf(ios::fixed); 
	cout.setf(ios::showpoint);
	cout.precision(2);
	// This block tells double type variables to print two digits after the decimal point

	cout << "What is the customer's full name?" << endl;
	getline (cin, customerName);
	// Asks user for a string and stores it in variable customerName
	/* Because there is generally a space between first and last names, we must use getline instead of cin */
	
	cout << "What was the odometer reading at the beginning of the rental period?" << endl;
	cin >> odoStart;
	cin.ignore(10000, '\n'); 
	// Asks user for an integer and stores it in variable odoStart
	
	cout << "What was the odometer reading at the end of the rental period?" <<endl;
	cin >> odoEnd;
	cin.ignore(10000, '\n'); 
	// Asks user for an integer and stores it in variable odoEnd
	
	cout << "How many days was the car rented?" <<endl;
	cin >> rentalDays;
	cin.ignore(10000, '\n'); 
	// Asks user for an integer and stores it in variable rentalDays
	
	cout << "Was the rental car a luxury vehicle? (y/n) " <<endl;
	cin >> luxury;
	cin.ignore(10000, '\n'); 
	// Asks user for a character (y or n) and stores it in variable luxury
	
	cout << "What month did the rental period begin (where Jan=1, Feb=2, etc.)?" <<endl;
	cin >> rentalMonth;
	cin.ignore(10000, '\n'); 
	// Asks user for an integer from 1 to 12 and stores it in variable rentalMonth

	char n;
	char y;
	int luxCharge;
	if (luxury == 'n')
	{
	  luxCharge = 33;
	} 
	else if (luxury == 'y')
	{
	  luxCharge = 61;
	} 
	// Stores the value 33 or 61 in variable luxCharge, depending on the user's input

	int rentalMiles;
	rentalMiles = odoEnd - odoStart;
	double mileCharge;

	if (rentalMiles <= 100) 
	{
	  mileCharge = rentalMiles * 0.27;
	}
	else if (100 < rentalMiles || rentalMiles <= 400) 
	{
		if (rentalMonth < 4 || rentalMonth > 11)
		{
		  mileCharge = rentalMiles * 0.27;
	    } 
	    else 
	    {
		  mileCharge = (100 * 0.27) + (rentalMiles - 100) * 0.21;
		} 
	}
	else if (rentalMiles > 400) 
	{
	  mileCharge = mileCharge + 0.19 * (rentalMiles - 400);
	}
	// Calculates the per-mile charge for rentalMiles > 100, 101 to 399, and < 400 miles

	double baseCharge;
	baseCharge = (rentalDays * luxCharge) + mileCharge;


	cout << "Odometer at Start: " << odoStart <<endl
		 << "Odometer at End: " << odoEnd <<endl
		 << "Rental Days: " << rentalDays <<endl
		 << "Customer Name: " << customerName <<endl
		 << "Luxury Vehicle? (y/n): " << luxury <<endl
		 << "Rental Month: " << rentalMonth <<endl
		 << "---" <<endl;
		 // Prints a summary of the information given by the user

	if (odoStart < 0) 
	{
	  cout << "The starting odometer reading must be nonnegative.";
	} 
	else if (odoEnd < odoStart) 
	{
	  cout << "The final odometer reading must be at least as large as the starting reading.";
	} 
	else if (rentalDays < 0) 
	{
	  cout << "The number of rental days must be positive.";
	} 
	else if (customerName == "") 
	{
	  cout << "You must enter a customer name.";
	} 
	else if (luxury != 'n' and luxury != 'y') 
	{
	  cout << "You must enter y or n.";
	}
	else if (12 < rentalMonth || rentalMonth < 1) 
	{
	  cout << "The month number must be in the range 1 through 12.";
	}
	else 
	{ 
	  cout << "The rental charge for " << customerName << " is $" << baseCharge;
	}
	// This block of code accounts for possible logical errors and prints an appropriate response
	// If there are no errors, the program prints the rental charge
	
	cout <<endl;
	return 0;
}
