#include <iostream>
#include <cctype>
#include <stdio.h>
#include <ctype.h>
#include <cassert>
using namespace std;

		// Checks if the entered state code is acceptable
		bool isValidUppercaseStateCode(string stateCode)
		{
			const string codes =
				"AL.AK.AZ.AR.CA.CO.CT.DE.FL.GA.HI.ID.IL.IN.IA.KS.KY."
				"LA.ME.MD.MA.MI.MN.MS.MO.MT.NE.NV.NH.NJ.NM.NY.NC.ND."
				"OH.OK.OR.PA.RI.SC.SD.TN.TX.UT.VT.VA.WA.WV.WI.WY";
			return (stateCode.size() == 2 &&
				stateCode.find('.') == string::npos  &&  // no '.' in stateCode
				codes.find(stateCode) != string::npos);  // match found
		}

		// The poll data can only contain letters and numbers
		// K is the index of the pollData string
		bool entryIsAlphanumeric(string pollData)
		{
			for (size_t k = 0; k != pollData.size(); k++)
			{
				if (isalpha(pollData[k]))
				{
					return 1;
				}
				if (isdigit(pollData[k]))
				{
					return 1;
				}
				if (pollData[k] == ',')
				{
					return 1;
				}
				else
					return 0;
			}
		
			if (pollData[0] == ',' || (pollData[pollData.size() - 1]) == ',')
			{
				return 0;
			}
		}

		bool validPrediction(string pollData)
		{	
			size_t k = 0;
			int step = 0;
			if (pollData.size() == 0)
			{
				return 1;
			}
			if (pollData.size() == 1)
			{
				return 0;
			}
			if (pollData.size() == 2)
			{
				string code;
				code = string() + pollData[k] + pollData[k + 1];
				if (isValidUppercaseStateCode(code) == 1)
				{
					return 1;
				}
				else
					return 1;
			}
			if (pollData.size() == 3)
			{
				return 0;
			}
			while (k <= pollData.size() - 1)
			{
				string code;
				code = string() + pollData[k] + pollData[k + 1];
				if (isValidUppercaseStateCode(code) == 1 && step == 0)
				{
					k += 2;
					step++;
						cout << k;
						cout << step;
					continue;
				}
				if (pollData[k] == ',' && step == 0)
				{
					return 0;
				}
				if (isdigit(pollData[k]) && step == 1)
				{
					k++;
					step++;
					cout << k;
						cout << step;
					continue;
				}
				if (pollData[k] == ',' && step == 1)
				{
					k++;
					step++;
					cout << k;
						cout << step;
					continue;
				}
				if (isdigit(pollData[k]) && step == 2)
				{
					k++;
					step++;
					cout << k;
						cout << step;
					continue;
				}
				if (isalpha(pollData[k]) && step == 2)
				{
					k++;
					step += 2;
					cout << k;
						cout << step;
					continue;
				}
				if (isalpha(pollData[k]) && step == 3)
				{
					k++;
					step++;
					cout << k;
						cout << step;
					continue;
				}
				if (pollData[k] == ',' && step == 4)
				{
					k++;
					step = 0;
					cout << k;
						cout << step;
					continue;
				}
				if (isdigit(pollData[k]) && step == 4)
				{
					k++;
					step = 2;
					continue;
				}
				if (step == 4)
				{
					return 1;
				}
				else return 0;
			}
		}

		bool hasProperSyntax(string pollData)
		{
			string stateCode;
			if (isValidUppercaseStateCode(stateCode) == 0)
			{
				return 0;
			}
			if (entryIsAlphanumeric(pollData) == 0)
			{
				return 0;
			}
			if (validPrediction(pollData) != 1)
			{
				return 0;
			}		
			else
				return 1;
		}
		
		/* Function returns 0 after setting seatTally to the total number of seats 
		that pollData predicts the party indicated by party will win.*/
		int tallySeats(string pollData, char party, int& seatTally)
		{
			int subTally = 0;
			if ((hasProperSyntax(pollData) == 0))
			{
				return 1;
			}
			if (!isalpha(party))
			{
				return 2;
			}
			for (size_t k = 0; k != pollData.size(); k++)
			{
			int place;
			int placeNext;
				if (pollData[k] == party)
				{
					place = pollData[k - 1];
					if (isdigit(pollData[k - 2]))
					{
						placeNext = (pollData[k - 2]) * 10;
						place += placeNext;
					}
				}
				subTally += place;
			}
			int tallySeats = subTally;
			return 0;
		}
	
int main()
{
	string pollData;
	pollData = "CA5D";
	char party; // Party can be R, D, I, G
	party = 'R';
	string stateCode;
	count << k;
	cout << step;

	assert(hasProperSyntax("CA5D"));
	assert(!hasProperSyntax("ZT5D,NY9R17D1I,VT,ne3r00D"));
	int seats;
	seats = -999;    // so we can detect whether tallySeats sets seats
	assert(tallySeats("CT5D,NY9R17D1I,VT,ne3r00D", 'd', seats) == 0 && seats == 22);
	seats = -999;    // so we can detect whether tallySeats sets seats
	assert(tallySeats("CT5D,NY9R17D1I,VT,ne3r00D", '%', seats) == 2 && seats == -999);
	
}